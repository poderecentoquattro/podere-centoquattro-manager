import type { Dispatch, SetStateAction } from "react";
import type {
  BookingForm,
  Guest,
  GuestForm,
} from "./types";

type GuestTabProps = {
  form: BookingForm;
  setForm: Dispatch<SetStateAction<BookingForm>>;
  guests: Guest[];
  guestForm: GuestForm;
  setGuestForm: Dispatch<SetStateAction<GuestForm>>;
};

const travelTypes = [
  {
    value: "solo",
    label: "Solo",
    emoji: "👤",
  },
  {
    value: "couple",
    label: "Coppia",
    emoji: "❤️",
  },
  {
    value: "family",
    label: "Famiglia",
    emoji: "👨‍👩‍👧‍👦",
  },
  {
    value: "group",
    label: "Gruppo",
    emoji: "👥",
  },
] as const;

export default function GuestTab({
  form,
  setForm,
  guests,
  guestForm,
  setGuestForm,
}: GuestTabProps) {
  return (
    <div className="rounded-xl border bg-white p-6">

      <h3 className="text-xl font-semibold text-gray-800">
        Ospite
      </h3>

      <p className="mb-6 text-sm text-gray-500">
        Seleziona un ospite esistente oppure inserisci i dati di un nuovo ospite.
      </p>

      <div className="mb-6">
        <label className="mb-2 block font-medium">
          Ospite
        </label>

        <select
          value={form.guest_id ?? ""}
          onChange={(e) =>
            setForm((prev) => ({
              ...prev,
              guest_id:
                e.target.value === ""
                  ? null
                  : Number(e.target.value),
            }))
          }
          className="w-full rounded-lg border p-3"
        >
          <option value="">
            Nuovo ospite...
          </option>

          {guests.map((g) => (
            <option key={g.id} value={g.id}>
              {g.cognome} {g.nome}
            </option>
          ))}
        </select>
      </div>

      <div className="grid gap-5 md:grid-cols-2">

        <div>
          <label className="mb-2 block font-medium">
            Nome
          </label>

          <input
            value={guestForm.nome}
            onChange={(e) =>
              setGuestForm((prev) => ({
                ...prev,
                nome: e.target.value,
              }))
            }
            className="w-full rounded-lg border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            Cognome
          </label>

          <input
            value={guestForm.cognome}
            onChange={(e) =>
              setGuestForm((prev) => ({
                ...prev,
                cognome: e.target.value,
              }))
            }
            className="w-full rounded-lg border p-3"
          />
        </div>

      </div>

      <div className="mt-5 grid gap-5 md:grid-cols-2">

        <div>
          <label className="mb-2 block font-medium">
            Email
          </label>

          <input
            type="email"
            value={guestForm.email}
            onChange={(e) =>
              setGuestForm((prev) => ({
                ...prev,
                email: e.target.value,
              }))
            }
            className="w-full rounded-lg border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            Telefono
          </label>

          <input
            value={guestForm.telefono}
            onChange={(e) =>
              setGuestForm((prev) => ({
                ...prev,
                telefono: e.target.value,
              }))
            }
            className="w-full rounded-lg border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            Provenienza
          </label>

          <input
            value={guestForm.nazionalita}
            onChange={(e) =>
              setGuestForm((prev) => ({
                ...prev,
                nazionalita: e.target.value,
              }))
            }
            className="w-full rounded-lg border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-medium">
            Data di nascita
          </label>

          <input
            type="date"
            value={guestForm.data_nascita}
            onChange={(e) =>
              setGuestForm((prev) => ({
                ...prev,
                data_nascita: e.target.value,
              }))
            }
            className="w-full rounded-lg border p-3"
          />
        </div>

          <div className="md:col-span-2">
          <label className="mb-3 block font-medium">
            Tipo di viaggio
          </label>

          <div className="grid grid-cols-2 gap-3">
            {travelTypes.map((tipo) => (
              <button
                key={tipo.value}
                type="button"
                onClick={() =>
                  setGuestForm((prev) => ({
                    ...prev,
                    tipo_viaggio: tipo.value as GuestForm["tipo_viaggio"],
                  }))
                }
                className={`rounded-xl border p-4 transition ${
                  guestForm.tipo_viaggio === tipo.value
                    ? "border-green-600 bg-green-50"
                    : "border-gray-300 hover:border-green-300"
                }`}
              >
                <div className="text-3xl">{tipo.emoji}</div>
                <div className="mt-2 font-semibold">
                  {tipo.label}
                </div>
              </button>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}